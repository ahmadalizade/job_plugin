<?php
/*
Plugin Name: Job Form
Plugin URI: https://jumpdev.com
description: Job Form
a plugin for job form
Version: 1.2
Author: Mr Alzd
Author URI: https://jumpdev.com
License: GPL2
*/

require_once 'inc/CRUD.php';

require_once 'form/ui_form.php';

require_once 'form/panel/form_inc.php';








