<?php

function insert(){
    global $wpdb,$table_prefix;
    $has_error = false;
    $msgs = [];

    if ($_SERVER['REQUEST_METHOD'] == "POST"){
        if (empty($_POST['full_name']) || empty($_POST['full_email']) || empty($_POST['full_phone'])){
            $has_error = true;
            $msgs[] = 'تمامی فیلد ها اجباریست';
        }
        if (!filter_var($_POST['full_email'],FILTER_VALIDATE_EMAIL)){
            $has_error = true;
            $msgs[] = 'فرمت ایمیل صحیح نیست';
        }
        if (!ctype_digit($_POST['full_phone'])) {
            $has_error = true;
            $msgs[] = "فرمت شماره تماس نادرست است";
        }

        if (!$has_error){
            $form_data = [
                'name' => sanitize_text_field($_POST['full_name']),
                'email' => sanitize_text_field($_POST['full_email']),
                'phone' => sanitize_text_field($_POST['full_phone'])
            ];

            $table_name = $table_prefix . 'job';

            $wpdb->insert($table_name,$form_data);
        }


    if ($has_error){
        foreach ($msgs as $msg){
            echo $msg."<br>";
        }
    }else{
        echo "انجام شد ، موفق باشید";
    }
    }
    ?>


<form action="" method="post">
    <div class="form-group">
        <label for="#name">نام و نام خانوادگی</label>
        <input name="full_name" placeholder="نام و نام خانوادگی" id="name">
    </div>
    <div class="form-group">
        <label for="#email">ایمیل</label>
        <input type="email" name="full_email" placeholder="ایمیل" id="email">
    </div>
    <div class="form-group">
        <label for="#phone">شماره تماس</label>
        <input name="full_phone" placeholder="شماره تماس" id="phone">
    </div>
    <div class="form-group">
        <input type="submit" name="submit" value="ثبت درخواست">
    </div>
</form>
<?php
}
add_shortcode('form_builder','insert');
?>



