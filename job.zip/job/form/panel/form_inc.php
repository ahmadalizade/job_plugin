<?php

add_action('admin_menu', 'form_custom');

function form_custom()
{
    add_menu_page('همه فرم ها', 'forms', 'manage_options', 'form_all', 'form_custom_page');
    add_submenu_page('form_all', 'بوک مارک ها', 'بوکمارک ها', 'manage_options', 'form_bookmark', 'form_bookmarks_page');
}

function form_custom_page()
{
    global $wpdb, $table_prefix;
    $all_results = $wpdb->get_results("SELECT * FROM {$table_prefix}job");

    $action = $_GET['action'];
    switch ($action) {
        case 'update' :
            $item_id = intval($_GET['item_id']);
            if ($item_id) {
                $wpdb->update(
                    $table_prefix . 'job',
                    ['mark' => 'yes'],
                    ['id' => $item_id]
                );
            }
            break;
            case 'delete' :
            $item_id = intval($_GET['item_id']);
            if ($item_id) {
                $wpdb->delete(
                    $table_prefix . 'job',
                    ['id' => $item_id],
                    ['%d']
                );
            }
            break;
    }
    require_once 'form_custom.php';
}

function form_bookmarks_page()
{
    global $wpdb, $table_prefix;
    $all_results = $wpdb->get_results("SELECT * FROM {$table_prefix}job where mark = 'yes'");
    require_once 'form_custom.php';
}