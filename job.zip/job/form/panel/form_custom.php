<div class="wrap">
    <h2>فرم ها</h2>
    <div class="container">
        <table class="widefat fixed">
            <thead>
            <tr>
                <th>تایید</th>
                <th>نام و نام خانوادگی</th>
                <th>ایمیل</th>
                <th>موبایل</th>
                <th>بوک مارک</th>

            </tr>
            </thead>

            <tbody>

            <?php if (isset($all_results) && count($all_results)) : ?>
                <?php foreach ($all_results as $result) : ?>
                    <tr>
                        <td>
                            <?php if ($result->mark == 'yes') : ?>
                                <span class="dashicons dashicons-yes"></span>
                            <?php else : ?>
                                <span class="dashicons dashicons-no"></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo $result->name ?>
                        </td>
                        <td>
                            <?php echo $result->email ?>
                        </td>
                        <td>
                            <?php echo $result->phone ?>
                        </td>
                        <td>
                            <a href="<?php echo add_query_arg([
                                'action' => 'update',
                                'item_id' => $result->id
                            ]); ?>">
                                <button>بوکمارک</button>
                            </a>
                            <a href="<?php echo add_query_arg([
                                'action' => 'delete',
                                'item_id' => $result->id
                            ]); ?>">
                                <button style="background: red;border: 0;padding: 10px;">حذف</button>
                            </a>


                        </td>


                    </tr>

                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>

            <tfoot>
            <tr>
                <th> تایید</th>
                <th>نام و نام خانوادگی</th>
                <th>ایمیل</th>
                <th>موبایل</th>
                <th>بوک مارک</th>

            </tr>
            </tfoot>
        </table>
    </div>


</div>