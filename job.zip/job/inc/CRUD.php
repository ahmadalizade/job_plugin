<?php

add_action('activated_plugin', 'create_insert');

function create_insert()
{

    global $wpdb;
    $table_name = $wpdb->prefix . "job";
    $charset_collate = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE $table_name (
     id int(9) NOT NULL AUTO_INCREMENT,
    name varchar(32) NOT NULL,
    email varchar(32) NOT NULL,
    phone varchar(32) NOT NULL,
    mark Enum('no', 'yes') NOT NULL,
    PRIMARY KEY  (id)
) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

//    $welcome_name = 'Mr. WordPress';
//    $welcome_email = 'email';
//    $welcome_phone = 'phone';
//
//    $wpdb->insert(
//        $table_name,
//        array(
//            'name' => $welcome_name,
//            'email' => $welcome_email,
//            'phone' => $welcome_phone,
//            'time' => current_time( 'mysql' ),
//        )
//    );


}


